import cv2 # Import the OpenCV library to enable computer vision
import numpy as np # Import the NumPy scientific computing library
 
# Author: Addison Sears-Collins
# https://automaticaddison.com
# Description: Detect corners on a chessboard
 
filename = 'frame71.jpg'
 
# Chessboard dimensions
number_of_squares_X = 9 # Number of chessboard squares along the x-axis
number_of_squares_Y = 6  # Number of chessboard squares along the y-axis
nX = number_of_squares_X - 1 # Number of interior corners along x-axis
nY = number_of_squares_Y - 1 # Number of interior corners along y-axis
 
def main():
     
  # Load an image
  image = cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
  
  print(cv2.imread(filename, cv2.IMREAD_COLOR).dtype )
  ther=cv2.adaptiveThreshold(image, 255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 0)
  
  #thershold, ther=cv2.threshold(image, 20,255, cv2.THRESH_BINARY)
  
  # Convert the image to grayscale
  cv2.imshow("soora", ther)
  cv2.waitKey(2000)

  # Find the corners on the chessboard
  success, corners = cv2.findChessboardCorners(ther, (nY, nX), None)
  print(success)
  # If the corners are found by the algorithm, draw them
  if success == True:
 
    # Draw the corners
    cv2.drawChessboardCorners(ther, (nY, nX), corners, success)
 
    # Create the output file name by removing the '.jpg' part
    size = len(filename)
    new_filename = filename[:size - 4]
    new_filename = new_filename + '_drawn_corners.jpg'     
     
    # Save the new image in the working directory
    cv2.imwrite(new_filename, ther)
 
    # Display the image 
    cv2.imshow("Image", ther) 
     
    # Display the window until any key is pressed
    cv2.waitKey(0) 
     
    # Close all windows
    cv2.destroyAllWindows() 
     
main()
